const { initDatabase, db } = require('../database/db');

async function initializeDatabase() {
  try {
    console.log('🚀 Initializing Campus Event Management Database...');
    
    await initDatabase();
    
    console.log('✅ Database initialization completed successfully!');
    console.log('📊 Database file created at: database/campus_events.db');
    
    // Close the database connection
    db.close((err) => {
      if (err) {
        console.error('Error closing database:', err.message);
      } else {
        console.log('🔒 Database connection closed.');
        process.exit(0);
      }
    });
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    process.exit(1);
  }
}

// Run the initialization
initializeDatabase();
