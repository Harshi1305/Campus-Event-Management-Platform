const { runQuery, db } = require('../database/db');

async function seedDatabase() {
  try {
    console.log('🌱 Seeding Campus Event Management Database...');
    
    // Insert sample colleges
    console.log('📚 Adding sample colleges...');
    const colleges = [
      { name: 'Indian Institute of Technology Delhi', code: 'IITD', location: 'New Delhi' },
      { name: 'Indian Institute of Technology Bombay', code: 'IITB', location: 'Mumbai' },
      { name: 'Indian Institute of Technology Madras', code: 'IITM', location: 'Chennai' },
      { name: 'Delhi Technological University', code: 'DTU', location: 'New Delhi' },
      { name: 'Netaji Subhas University of Technology', code: 'NSUT', location: 'New Delhi' }
    ];
    
    for (const college of colleges) {
      await runQuery(`
        INSERT OR IGNORE INTO colleges (name, code, location) VALUES (?, ?, ?)
      `, [college.name, college.code, college.location]);
    }
    
    // Insert sample students
    console.log('👨‍🎓 Adding sample students...');
    const students = [
      // IIT Delhi students
      { college_id: 1, student_id: 'IITD2021001', name: 'Arjun Sharma', email: 'arjun.sharma@iitd.ac.in', phone: '9876543210', year_of_study: 3, department: 'Computer Science' },
      { college_id: 1, student_id: 'IITD2021002', name: 'Priya Patel', email: 'priya.patel@iitd.ac.in', phone: '9876543211', year_of_study: 2, department: 'Electronics' },
      { college_id: 1, student_id: 'IITD2021003', name: 'Rahul Kumar', email: 'rahul.kumar@iitd.ac.in', phone: '9876543212', year_of_study: 4, department: 'Mechanical' },
      { college_id: 1, student_id: 'IITD2021004', name: 'Sneha Gupta', email: 'sneha.gupta@iitd.ac.in', phone: '9876543213', year_of_study: 1, department: 'Computer Science' },
      { college_id: 1, student_id: 'IITD2021005', name: 'Vikram Singh', email: 'vikram.singh@iitd.ac.in', phone: '9876543214', year_of_study: 3, department: 'Civil' },
      
      // IIT Bombay students
      { college_id: 2, student_id: 'IITB2021001', name: 'Ananya Reddy', email: 'ananya.reddy@iitb.ac.in', phone: '9876543215', year_of_study: 2, department: 'Computer Science' },
      { college_id: 2, student_id: 'IITB2021002', name: 'Karthik Nair', email: 'karthik.nair@iitb.ac.in', phone: '9876543216', year_of_study: 4, department: 'Electronics' },
      { college_id: 2, student_id: 'IITB2021003', name: 'Meera Joshi', email: 'meera.joshi@iitb.ac.in', phone: '9876543217', year_of_study: 1, department: 'Mechanical' },
      { college_id: 2, student_id: 'IITB2021004', name: 'Rohan Desai', email: 'rohan.desai@iitb.ac.in', phone: '9876543218', year_of_study: 3, department: 'Computer Science' },
      { college_id: 2, student_id: 'IITB2021005', name: 'Tanya Agarwal', email: 'tanya.agarwal@iitb.ac.in', phone: '9876543219', year_of_study: 2, department: 'Civil' },
      
      // DTU students
      { college_id: 4, student_id: 'DTU2021001', name: 'Amit Verma', email: 'amit.verma@dtu.ac.in', phone: '9876543220', year_of_study: 3, department: 'Computer Science' },
      { college_id: 4, student_id: 'DTU2021002', name: 'Deepika Sharma', email: 'deepika.sharma@dtu.ac.in', phone: '9876543221', year_of_study: 2, department: 'Electronics' },
      { college_id: 4, student_id: 'DTU2021003', name: 'Gaurav Malhotra', email: 'gaurav.malhotra@dtu.ac.in', phone: '9876543222', year_of_study: 4, department: 'Mechanical' },
      { college_id: 4, student_id: 'DTU2021004', name: 'Isha Jain', email: 'isha.jain@dtu.ac.in', phone: '9876543223', year_of_study: 1, department: 'Computer Science' },
      { college_id: 4, student_id: 'DTU2021005', name: 'Manish Kumar', email: 'manish.kumar@dtu.ac.in', phone: '9876543224', year_of_study: 3, department: 'Civil' }
    ];
    
    for (const student of students) {
      await runQuery(`
        INSERT OR IGNORE INTO students (college_id, student_id, name, email, phone, year_of_study, department) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [student.college_id, student.student_id, student.name, student.email, student.phone, student.year_of_study, student.department]);
    }
    
    // Insert sample events
    console.log('🎉 Adding sample events...');
    const events = [
      // IIT Delhi events
      { college_id: 1, title: 'TechFest 2024', description: 'Annual technology festival with coding competitions, workshops, and tech talks', event_type: 'Fest', start_date: '2024-03-15 09:00:00', end_date: '2024-03-17 18:00:00', location: 'IIT Delhi Campus', max_capacity: 500, registration_deadline: '2024-03-10 23:59:59', created_by: 'admin' },
      { college_id: 1, title: 'Machine Learning Workshop', description: 'Hands-on workshop on ML algorithms and applications', event_type: 'Workshop', start_date: '2024-02-20 10:00:00', end_date: '2024-02-20 16:00:00', location: 'Computer Science Department', max_capacity: 50, registration_deadline: '2024-02-15 23:59:59', created_by: 'admin' },
      { college_id: 1, title: 'Startup Pitch Competition', description: 'Students pitch their innovative startup ideas to industry experts', event_type: 'Competition', start_date: '2024-04-10 14:00:00', end_date: '2024-04-10 18:00:00', location: 'Auditorium', max_capacity: 200, registration_deadline: '2024-04-05 23:59:59', created_by: 'admin' },
      { college_id: 1, title: 'AI in Healthcare Seminar', description: 'Exploring the role of AI in modern healthcare systems', event_type: 'Seminar', start_date: '2024-02-25 15:00:00', end_date: '2024-02-25 17:00:00', location: 'Lecture Hall 1', max_capacity: 100, registration_deadline: '2024-02-20 23:59:59', created_by: 'admin' },
      
      // IIT Bombay events
      { college_id: 2, title: 'Mood Indigo 2024', description: 'Cultural festival with music, dance, and art competitions', event_type: 'Fest', start_date: '2024-03-20 10:00:00', end_date: '2024-03-23 22:00:00', location: 'IIT Bombay Campus', max_capacity: 1000, registration_deadline: '2024-03-15 23:59:59', created_by: 'admin' },
      { college_id: 2, title: 'Blockchain Development Workshop', description: 'Learn blockchain fundamentals and smart contract development', event_type: 'Workshop', start_date: '2024-02-28 09:00:00', end_date: '2024-02-28 17:00:00', location: 'Computer Center', max_capacity: 40, registration_deadline: '2024-02-25 23:59:59', created_by: 'admin' },
      { college_id: 2, title: 'Robotics Competition', description: 'Build and compete with autonomous robots', event_type: 'Competition', start_date: '2024-04-15 09:00:00', end_date: '2024-04-15 18:00:00', location: 'Mechanical Workshop', max_capacity: 30, registration_deadline: '2024-04-10 23:59:59', created_by: 'admin' },
      
      // DTU events
      { college_id: 4, title: 'Engifest 2024', description: 'Engineering festival with technical competitions and exhibitions', event_type: 'Fest', start_date: '2024-03-25 09:00:00', end_date: '2024-03-27 20:00:00', location: 'DTU Campus', max_capacity: 800, registration_deadline: '2024-03-20 23:59:59', created_by: 'admin' },
      { college_id: 4, title: 'Data Science Bootcamp', description: 'Intensive 3-day bootcamp on data science and analytics', event_type: 'Workshop', start_date: '2024-03-05 09:00:00', end_date: '2024-03-07 17:00:00', location: 'Computer Lab', max_capacity: 60, registration_deadline: '2024-02-28 23:59:59', created_by: 'admin' },
      { college_id: 4, title: 'Cybersecurity Awareness Talk', description: 'Understanding modern cybersecurity threats and protection measures', event_type: 'Seminar', start_date: '2024-02-22 16:00:00', end_date: '2024-02-22 18:00:00', location: 'Seminar Hall', max_capacity: 150, registration_deadline: '2024-02-18 23:59:59', created_by: 'admin' }
    ];
    
    for (const event of events) {
      await runQuery(`
        INSERT OR IGNORE INTO events (college_id, title, description, event_type, start_date, end_date, location, max_capacity, registration_deadline, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [event.college_id, event.title, event.description, event.event_type, event.start_date, event.end_date, event.location, event.max_capacity, event.registration_deadline, event.created_by]);
    }
    
    // Insert sample registrations
    console.log('📝 Adding sample registrations...');
    const registrations = [
      // TechFest 2024 registrations
      { event_id: 1, student_id: 1 }, { event_id: 1, student_id: 2 }, { event_id: 1, student_id: 3 }, { event_id: 1, student_id: 4 }, { event_id: 1, student_id: 5 },
      { event_id: 1, student_id: 6 }, { event_id: 1, student_id: 7 }, { event_id: 1, student_id: 8 }, { event_id: 1, student_id: 9 }, { event_id: 1, student_id: 10 },
      
      // ML Workshop registrations
      { event_id: 2, student_id: 1 }, { event_id: 2, student_id: 4 }, { event_id: 2, student_id: 6 }, { event_id: 2, student_id: 8 }, { event_id: 2, student_id: 11 },
      { event_id: 2, student_id: 14 },
      
      // Startup Pitch registrations
      { event_id: 3, student_id: 1 }, { event_id: 3, student_id: 3 }, { event_id: 3, student_id: 6 }, { event_id: 3, student_id: 8 }, { event_id: 3, student_id: 11 },
      
      // AI Seminar registrations
      { event_id: 4, student_id: 1 }, { event_id: 4, student_id: 2 }, { event_id: 4, student_id: 4 }, { event_id: 4, student_id: 6 }, { event_id: 4, student_id: 8 },
      { event_id: 4, student_id: 11 }, { event_id: 4, student_id: 12 }, { event_id: 4, student_id: 14 },
      
      // Mood Indigo registrations
      { event_id: 5, student_id: 6 }, { event_id: 5, student_id: 7 }, { event_id: 5, student_id: 8 }, { event_id: 5, student_id: 9 }, { event_id: 5, student_id: 10 },
      
      // Blockchain Workshop registrations
      { event_id: 6, student_id: 6 }, { event_id: 6, student_id: 8 }, { event_id: 6, student_id: 11 }, { event_id: 6, student_id: 14 },
      
      // Engifest registrations
      { event_id: 8, student_id: 11 }, { event_id: 8, student_id: 12 }, { event_id: 8, student_id: 13 }, { event_id: 8, student_id: 14 }, { event_id: 8, student_id: 15 },
      
      // Data Science Bootcamp registrations
      { event_id: 9, student_id: 1 }, { event_id: 9, student_id: 4 }, { event_id: 9, student_id: 6 }, { event_id: 9, student_id: 8 }, { event_id: 9, student_id: 11 },
      { event_id: 9, student_id: 14 },
      
      // Cybersecurity Talk registrations
      { event_id: 10, student_id: 1 }, { event_id: 10, student_id: 2 }, { event_id: 10, student_id: 4 }, { event_id: 10, student_id: 6 }, { event_id: 10, student_id: 8 },
      { event_id: 10, student_id: 11 }, { event_id: 10, student_id: 12 }, { event_id: 10, student_id: 14 }
    ];
    
    for (const registration of registrations) {
      await runQuery(`
        INSERT OR IGNORE INTO registrations (event_id, student_id) VALUES (?, ?)
      `, [registration.event_id, registration.student_id]);
    }
    
    // Insert sample attendance (some students attended events)
    console.log('✅ Adding sample attendance...');
    const attendance = [
      // TechFest attendance (most students attended)
      { event_id: 1, student_id: 1 }, { event_id: 1, student_id: 2 }, { event_id: 1, student_id: 3 }, { event_id: 1, student_id: 4 }, { event_id: 1, student_id: 5 },
      { event_id: 1, student_id: 6 }, { event_id: 1, student_id: 7 }, { event_id: 1, student_id: 8 }, { event_id: 1, student_id: 9 },
      
      // ML Workshop attendance (all registered students attended)
      { event_id: 2, student_id: 1 }, { event_id: 2, student_id: 4 }, { event_id: 2, student_id: 6 }, { event_id: 2, student_id: 8 }, { event_id: 2, student_id: 11 },
      { event_id: 2, student_id: 14 },
      
      // Startup Pitch attendance (most attended)
      { event_id: 3, student_id: 1 }, { event_id: 3, student_id: 3 }, { event_id: 3, student_id: 6 }, { event_id: 3, student_id: 8 },
      
      // AI Seminar attendance (all attended)
      { event_id: 4, student_id: 1 }, { event_id: 4, student_id: 2 }, { event_id: 4, student_id: 4 }, { event_id: 4, student_id: 6 }, { event_id: 4, student_id: 8 },
      { event_id: 4, student_id: 11 }, { event_id: 4, student_id: 12 }, { event_id: 4, student_id: 14 },
      
      // Mood Indigo attendance (partial)
      { event_id: 5, student_id: 6 }, { event_id: 5, student_id: 7 }, { event_id: 5, student_id: 8 }, { event_id: 5, student_id: 9 },
      
      // Blockchain Workshop attendance (all attended)
      { event_id: 6, student_id: 6 }, { event_id: 6, student_id: 8 }, { event_id: 6, student_id: 11 }, { event_id: 6, student_id: 14 },
      
      // Engifest attendance (most attended)
      { event_id: 8, student_id: 11 }, { event_id: 8, student_id: 12 }, { event_id: 8, student_id: 13 }, { event_id: 8, student_id: 14 },
      
      // Data Science Bootcamp attendance (all attended)
      { event_id: 9, student_id: 1 }, { event_id: 9, student_id: 4 }, { event_id: 9, student_id: 6 }, { event_id: 9, student_id: 8 }, { event_id: 9, student_id: 11 },
      { event_id: 9, student_id: 14 },
      
      // Cybersecurity Talk attendance (all attended)
      { event_id: 10, student_id: 1 }, { event_id: 10, student_id: 2 }, { event_id: 10, student_id: 4 }, { event_id: 10, student_id: 6 }, { event_id: 10, student_id: 8 },
      { event_id: 10, student_id: 11 }, { event_id: 10, student_id: 12 }, { event_id: 10, student_id: 14 }
    ];
    
    for (const att of attendance) {
      await runQuery(`
        INSERT OR IGNORE INTO attendance (event_id, student_id) VALUES (?, ?)
      `, [att.event_id, att.student_id]);
    }
    
    // Insert sample feedback
    console.log('💬 Adding sample feedback...');
    const feedback = [
      // TechFest feedback
      { event_id: 1, student_id: 1, rating: 5, comment: 'Amazing event! Great organization and interesting competitions.' },
      { event_id: 1, student_id: 2, rating: 4, comment: 'Very well organized. Could have more hands-on workshops.' },
      { event_id: 1, student_id: 3, rating: 5, comment: 'Excellent event! Learned a lot from the tech talks.' },
      { event_id: 1, student_id: 4, rating: 4, comment: 'Good event overall. Food could be better.' },
      { event_id: 1, student_id: 5, rating: 3, comment: 'Decent event but some sessions were too basic.' },
      { event_id: 1, student_id: 6, rating: 5, comment: 'Fantastic experience! Highly recommend.' },
      { event_id: 1, student_id: 7, rating: 4, comment: 'Well organized with good speakers.' },
      { event_id: 1, student_id: 8, rating: 5, comment: 'Outstanding event! Great networking opportunities.' },
      { event_id: 1, student_id: 9, rating: 4, comment: 'Good event with valuable insights.' },
      
      // ML Workshop feedback
      { event_id: 2, student_id: 1, rating: 5, comment: 'Excellent workshop! Very practical and hands-on.' },
      { event_id: 2, student_id: 4, rating: 4, comment: 'Good content but could use more examples.' },
      { event_id: 2, student_id: 6, rating: 5, comment: 'Amazing workshop! Instructor was very knowledgeable.' },
      { event_id: 2, student_id: 8, rating: 4, comment: 'Great learning experience. More time would be helpful.' },
      { event_id: 2, student_id: 11, rating: 5, comment: 'Perfect workshop! Learned a lot in one day.' },
      { event_id: 2, student_id: 14, rating: 4, comment: 'Good workshop with practical applications.' },
      
      // Startup Pitch feedback
      { event_id: 3, student_id: 1, rating: 4, comment: 'Great competition! Good feedback from judges.' },
      { event_id: 3, student_id: 3, rating: 5, comment: 'Excellent platform for showcasing ideas.' },
      { event_id: 3, student_id: 6, rating: 4, comment: 'Well organized competition with fair judging.' },
      { event_id: 3, student_id: 8, rating: 5, comment: 'Amazing experience! Great networking opportunity.' },
      
      // AI Seminar feedback
      { event_id: 4, student_id: 1, rating: 4, comment: 'Informative seminar with good insights.' },
      { event_id: 4, student_id: 2, rating: 5, comment: 'Excellent presentation! Very relevant topic.' },
      { event_id: 4, student_id: 4, rating: 4, comment: 'Good seminar but could be more interactive.' },
      { event_id: 4, student_id: 6, rating: 5, comment: 'Outstanding seminar! Great speaker.' },
      { event_id: 4, student_id: 8, rating: 4, comment: 'Very informative and well-presented.' },
      { event_id: 4, student_id: 11, rating: 5, comment: 'Excellent content and delivery.' },
      { event_id: 4, student_id: 12, rating: 4, comment: 'Good seminar with practical examples.' },
      { event_id: 4, student_id: 14, rating: 5, comment: 'Amazing seminar! Very insightful.' },
      
      // Mood Indigo feedback
      { event_id: 5, student_id: 6, rating: 5, comment: 'Fantastic cultural festival! Great performances.' },
      { event_id: 5, student_id: 7, rating: 4, comment: 'Good event with diverse cultural activities.' },
      { event_id: 5, student_id: 8, rating: 5, comment: 'Amazing festival! Great atmosphere.' },
      { event_id: 5, student_id: 9, rating: 4, comment: 'Well organized cultural event.' },
      
      // Blockchain Workshop feedback
      { event_id: 6, student_id: 6, rating: 5, comment: 'Excellent workshop! Very comprehensive.' },
      { event_id: 6, student_id: 8, rating: 4, comment: 'Good workshop with practical examples.' },
      { event_id: 6, student_id: 11, rating: 5, comment: 'Outstanding workshop! Learned a lot.' },
      { event_id: 6, student_id: 14, rating: 4, comment: 'Great workshop with hands-on learning.' },
      
      // Engifest feedback
      { event_id: 8, student_id: 11, rating: 4, comment: 'Good engineering festival with technical competitions.' },
      { event_id: 8, student_id: 12, rating: 5, comment: 'Excellent festival! Great technical content.' },
      { event_id: 8, student_id: 13, rating: 4, comment: 'Well organized with good competitions.' },
      { event_id: 8, student_id: 14, rating: 5, comment: 'Amazing festival! Great learning experience.' },
      
      // Data Science Bootcamp feedback
      { event_id: 9, student_id: 1, rating: 5, comment: 'Excellent bootcamp! Very intensive and comprehensive.' },
      { event_id: 9, student_id: 4, rating: 4, comment: 'Good bootcamp with practical projects.' },
      { event_id: 9, student_id: 6, rating: 5, comment: 'Outstanding bootcamp! Great instructors.' },
      { event_id: 9, student_id: 8, rating: 4, comment: 'Very good bootcamp with hands-on learning.' },
      { event_id: 9, student_id: 11, rating: 5, comment: 'Amazing bootcamp! Learned a lot in 3 days.' },
      { event_id: 9, student_id: 14, rating: 4, comment: 'Great bootcamp with practical applications.' },
      
      // Cybersecurity Talk feedback
      { event_id: 10, student_id: 1, rating: 4, comment: 'Informative talk on cybersecurity threats.' },
      { event_id: 10, student_id: 2, rating: 5, comment: 'Excellent presentation! Very relevant topic.' },
      { event_id: 10, student_id: 4, rating: 4, comment: 'Good talk with practical examples.' },
      { event_id: 10, student_id: 6, rating: 5, comment: 'Outstanding talk! Great insights.' },
      { event_id: 10, student_id: 8, rating: 4, comment: 'Very informative and well-presented.' },
      { event_id: 10, student_id: 11, rating: 5, comment: 'Excellent talk! Very educational.' },
      { event_id: 10, student_id: 12, rating: 4, comment: 'Good talk with relevant examples.' },
      { event_id: 10, student_id: 14, rating: 5, comment: 'Amazing talk! Very insightful.' }
    ];
    
    for (const fb of feedback) {
      await runQuery(`
        INSERT OR IGNORE INTO feedback (event_id, student_id, rating, comment) VALUES (?, ?, ?, ?)
      `, [fb.event_id, fb.student_id, fb.rating, fb.comment]);
    }
    
    console.log('✅ Database seeding completed successfully!');
    console.log('📊 Sample data includes:');
    console.log('   - 5 colleges');
    console.log('   - 15 students');
    console.log('   - 10 events');
    console.log('   - 50+ registrations');
    console.log('   - 40+ attendance records');
    console.log('   - 50+ feedback entries');
    
    // Close the database connection
    db.close((err) => {
      if (err) {
        console.error('Error closing database:', err.message);
      } else {
        console.log('🔒 Database connection closed.');
        process.exit(0);
      }
    });
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

// Run the seeding
seedDatabase();
