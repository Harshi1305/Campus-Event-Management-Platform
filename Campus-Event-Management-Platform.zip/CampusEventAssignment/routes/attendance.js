const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all attendance records (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { event_id, student_id, status, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT a.*, e.title as event_title, e.event_type, e.start_date,
             s.name as student_name, s.email as student_email,
             c.name as college_name
      FROM attendance a
      LEFT JOIN events e ON a.event_id = e.id
      LEFT JOIN students s ON a.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (event_id) {
      sql += ' AND a.event_id = ?';
      params.push(event_id);
    }
    
    if (student_id) {
      sql += ' AND a.student_id = ?';
      params.push(student_id);
    }
    
    if (status) {
      sql += ' AND a.status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY a.check_in_time DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const attendance = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: attendance,
      count: attendance.length
    });
  } catch (error) {
    console.error('Error fetching attendance:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch attendance',
      message: error.message
    });
  }
});

// Mark attendance (check-in)
router.post('/checkin', async (req, res) => {
  try {
    const { event_id, student_id } = req.body;
    
    // Validate required fields
    if (!event_id || !student_id) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['event_id', 'student_id']
      });
    }
    
    // Check if student is registered for the event
    const registration = await getQuery(`
      SELECT * FROM registrations 
      WHERE event_id = ? AND student_id = ? AND status = 'registered'
    `, [event_id, student_id]);
    
    if (!registration) {
      return res.status(400).json({
        success: false,
        error: 'Student is not registered for this event'
      });
    }
    
    // Check if attendance is already marked
    const existingAttendance = await getQuery(`
      SELECT * FROM attendance WHERE event_id = ? AND student_id = ?
    `, [event_id, student_id]);
    
    if (existingAttendance) {
      return res.status(400).json({
        success: false,
        error: 'Attendance already marked for this student'
      });
    }
    
    const result = await runQuery(`
      INSERT INTO attendance (event_id, student_id, status) VALUES (?, ?, 'present')
    `, [event_id, student_id]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'Attendance marked successfully'
      }
    });
  } catch (error) {
    console.error('Error marking attendance:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to mark attendance',
      message: error.message
    });
  }
});

// Mark check-out
router.put('/checkout/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await runQuery(`
      UPDATE attendance SET check_out_time = CURRENT_TIMESTAMP WHERE id = ?
    `, [id]);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Attendance record not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Check-out recorded successfully'
      }
    });
  } catch (error) {
    console.error('Error recording check-out:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to record check-out',
      message: error.message
    });
  }
});

// Get attendance for a specific event
router.get('/event/:event_id', async (req, res) => {
  try {
    const { event_id } = req.params;
    const { status, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT a.*, s.name as student_name, s.email as student_email,
             s.year_of_study, s.department, c.name as college_name
      FROM attendance a
      LEFT JOIN students s ON a.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE a.event_id = ?
    `;
    
    const params = [event_id];
    
    if (status) {
      sql += ' AND a.status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY a.check_in_time DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const attendance = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: attendance,
      count: attendance.length
    });
  } catch (error) {
    console.error('Error fetching event attendance:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch event attendance',
      message: error.message
    });
  }
});

// Get attendance summary for an event
router.get('/event/:event_id/summary', async (req, res) => {
  try {
    const { event_id } = req.params;
    
    const summary = await getQuery(`
      SELECT 
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT a.id) as total_attendance,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / COUNT(DISTINCT r.id)), 2
        ) as attendance_percentage
      FROM registrations r
      LEFT JOIN attendance a ON r.event_id = a.event_id AND r.student_id = a.student_id
      WHERE r.event_id = ? AND r.status = 'registered'
    `, [event_id]);
    
    res.json({
      success: true,
      data: summary
    });
  } catch (error) {
    console.error('Error fetching attendance summary:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch attendance summary',
      message: error.message
    });
  }
});

module.exports = router;
