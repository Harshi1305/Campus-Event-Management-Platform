const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all registrations (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { event_id, student_id, status, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT r.*, e.title as event_title, e.event_type, e.start_date,
             s.name as student_name, s.email as student_email,
             c.name as college_name
      FROM registrations r
      LEFT JOIN events e ON r.event_id = e.id
      LEFT JOIN students s ON r.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (event_id) {
      sql += ' AND r.event_id = ?';
      params.push(event_id);
    }
    
    if (student_id) {
      sql += ' AND r.student_id = ?';
      params.push(student_id);
    }
    
    if (status) {
      sql += ' AND r.status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY r.registration_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const registrations = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: registrations,
      count: registrations.length
    });
  } catch (error) {
    console.error('Error fetching registrations:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch registrations',
      message: error.message
    });
  }
});

// Register student for an event
router.post('/', async (req, res) => {
  try {
    const { event_id, student_id } = req.body;
    
    // Validate required fields
    if (!event_id || !student_id) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['event_id', 'student_id']
      });
    }
    
    // Check if event exists and is active
    const event = await getQuery(`
      SELECT * FROM events WHERE id = ? AND status = 'active'
    `, [event_id]);
    
    if (!event) {
      return res.status(404).json({
        success: false,
        error: 'Event not found or not active'
      });
    }
    
    // Check if registration deadline has passed
    if (event.registration_deadline && new Date() > new Date(event.registration_deadline)) {
      return res.status(400).json({
        success: false,
        error: 'Registration deadline has passed'
      });
    }
    
    // Check if event is at capacity
    if (event.max_capacity) {
      const currentRegistrations = await getQuery(`
        SELECT COUNT(*) as count FROM registrations WHERE event_id = ? AND status = 'registered'
      `, [event_id]);
      
      if (currentRegistrations.count >= event.max_capacity) {
        return res.status(400).json({
          success: false,
          error: 'Event is at maximum capacity'
        });
      }
    }
    
    // Check if student is already registered
    const existingRegistration = await getQuery(`
      SELECT * FROM registrations WHERE event_id = ? AND student_id = ?
    `, [event_id, student_id]);
    
    if (existingRegistration) {
      return res.status(400).json({
        success: false,
        error: 'Student is already registered for this event'
      });
    }
    
    const result = await runQuery(`
      INSERT INTO registrations (event_id, student_id) VALUES (?, ?)
    `, [event_id, student_id]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'Student registered successfully'
      }
    });
  } catch (error) {
    console.error('Error registering student:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to register student',
      message: error.message
    });
  }
});

// Cancel registration
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await runQuery(`
      UPDATE registrations SET status = 'cancelled' WHERE id = ?
    `, [id]);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Registration not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Registration cancelled successfully'
      }
    });
  } catch (error) {
    console.error('Error cancelling registration:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to cancel registration',
      message: error.message
    });
  }
});

// Get registration by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const registration = await getQuery(`
      SELECT r.*, e.title as event_title, e.event_type, e.start_date,
             s.name as student_name, s.email as student_email,
             c.name as college_name
      FROM registrations r
      LEFT JOIN events e ON r.event_id = e.id
      LEFT JOIN students s ON r.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE r.id = ?
    `, [id]);
    
    if (!registration) {
      return res.status(404).json({
        success: false,
        error: 'Registration not found'
      });
    }
    
    res.json({
      success: true,
      data: registration
    });
  } catch (error) {
    console.error('Error fetching registration:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch registration',
      message: error.message
    });
  }
});

// Get registrations for a specific event
router.get('/event/:event_id', async (req, res) => {
  try {
    const { event_id } = req.params;
    const { status, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT r.*, s.name as student_name, s.email as student_email,
             s.year_of_study, s.department, c.name as college_name
      FROM registrations r
      LEFT JOIN students s ON r.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE r.event_id = ?
    `;
    
    const params = [event_id];
    
    if (status) {
      sql += ' AND r.status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY r.registration_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const registrations = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: registrations,
      count: registrations.length
    });
  } catch (error) {
    console.error('Error fetching event registrations:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch event registrations',
      message: error.message
    });
  }
});

module.exports = router;
