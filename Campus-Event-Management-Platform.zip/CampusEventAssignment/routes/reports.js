const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Event Popularity Report - Sorted by number of registrations
router.get('/event-popularity', async (req, res) => {
  try {
    const { college_id, event_type, limit = 20, offset = 0 } = req.query;
    
    let sql = `
      SELECT 
        e.id,
        e.title,
        e.event_type,
        e.start_date,
        e.location,
        c.name as college_name,
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT a.id) as total_attendance,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_rating,
        COUNT(DISTINCT f.id) as feedback_count
      FROM events e
      LEFT JOIN colleges c ON e.college_id = c.id
      LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
      LEFT JOIN attendance a ON e.id = a.event_id
      LEFT JOIN feedback f ON e.id = f.event_id
      WHERE e.status = 'active'
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND e.college_id = ?';
      params.push(college_id);
    }
    
    if (event_type) {
      sql += ' AND e.event_type = ?';
      params.push(event_type);
    }
    
    sql += `
      GROUP BY e.id
      ORDER BY total_registrations DESC, average_rating DESC
      LIMIT ? OFFSET ?
    `;
    params.push(parseInt(limit), parseInt(offset));
    
    const events = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: events,
      count: events.length,
      report_type: 'Event Popularity Report'
    });
  } catch (error) {
    console.error('Error generating event popularity report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate event popularity report',
      message: error.message
    });
  }
});

// Student Participation Report - How many events a student attended
router.get('/student-participation', async (req, res) => {
  try {
    const { college_id, department, year_of_study, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT 
        s.id,
        s.student_id,
        s.name,
        s.email,
        s.department,
        s.year_of_study,
        c.name as college_name,
        COUNT(DISTINCT r.id) as events_registered,
        COUNT(DISTINCT a.id) as events_attended,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_feedback_given,
        COUNT(DISTINCT f.id) as feedback_submitted
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      LEFT JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
      LEFT JOIN attendance a ON s.id = a.student_id
      LEFT JOIN feedback f ON s.id = f.student_id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND s.college_id = ?';
      params.push(college_id);
    }
    
    if (department) {
      sql += ' AND s.department = ?';
      params.push(department);
    }
    
    if (year_of_study) {
      sql += ' AND s.year_of_study = ?';
      params.push(year_of_study);
    }
    
    sql += `
      GROUP BY s.id
      HAVING events_registered > 0
      ORDER BY events_attended DESC, attendance_percentage DESC
      LIMIT ? OFFSET ?
    `;
    params.push(parseInt(limit), parseInt(offset));
    
    const students = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: students,
      count: students.length,
      report_type: 'Student Participation Report'
    });
  } catch (error) {
    console.error('Error generating student participation report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate student participation report',
      message: error.message
    });
  }
});

// Top 3 Most Active Students (Bonus)
router.get('/top-active-students', async (req, res) => {
  try {
    const { college_id, limit = 3 } = req.query;
    
    let sql = `
      SELECT 
        s.id,
        s.student_id,
        s.name,
        s.email,
        s.department,
        s.year_of_study,
        c.name as college_name,
        COUNT(DISTINCT r.id) as events_registered,
        COUNT(DISTINCT a.id) as events_attended,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_feedback_given,
        COUNT(DISTINCT f.id) as feedback_submitted,
        (COUNT(DISTINCT a.id) + COUNT(DISTINCT f.id)) as activity_score
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      LEFT JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
      LEFT JOIN attendance a ON s.id = a.student_id
      LEFT JOIN feedback f ON s.id = f.student_id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND s.college_id = ?';
      params.push(college_id);
    }
    
    sql += `
      GROUP BY s.id
      HAVING events_registered > 0
      ORDER BY activity_score DESC, events_attended DESC, attendance_percentage DESC
      LIMIT ?
    `;
    params.push(parseInt(limit));
    
    const topStudents = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: topStudents,
      count: topStudents.length,
      report_type: 'Top Most Active Students'
    });
  } catch (error) {
    console.error('Error generating top active students report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate top active students report',
      message: error.message
    });
  }
});

// Event Type Analysis Report (Bonus - Flexible reports)
router.get('/event-type-analysis', async (req, res) => {
  try {
    const { college_id } = req.query;
    
    let sql = `
      SELECT 
        e.event_type,
        COUNT(DISTINCT e.id) as total_events,
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT a.id) as total_attendance,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_rating,
        COUNT(DISTINCT f.id) as total_feedback,
        ROUND(AVG(CAST(strftime('%s', e.end_date) - strftime('%s', e.start_date) AS FLOAT) / 3600), 2) as avg_duration_hours
      FROM events e
      LEFT JOIN colleges c ON e.college_id = c.id
      LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
      LEFT JOIN attendance a ON e.id = a.event_id
      LEFT JOIN feedback f ON e.id = f.event_id
      WHERE e.status = 'active'
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND e.college_id = ?';
      params.push(college_id);
    }
    
    sql += `
      GROUP BY e.event_type
      ORDER BY total_registrations DESC
    `;
    
    const analysis = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: analysis,
      count: analysis.length,
      report_type: 'Event Type Analysis Report'
    });
  } catch (error) {
    console.error('Error generating event type analysis:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate event type analysis',
      message: error.message
    });
  }
});

// College Performance Report
router.get('/college-performance', async (req, res) => {
  try {
    const sql = `
      SELECT 
        c.id,
        c.name as college_name,
        c.code as college_code,
        c.location,
        COUNT(DISTINCT s.id) as total_students,
        COUNT(DISTINCT e.id) as total_events,
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT a.id) as total_attendance,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as overall_attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_event_rating,
        COUNT(DISTINCT f.id) as total_feedback
      FROM colleges c
      LEFT JOIN students s ON c.id = s.college_id
      LEFT JOIN events e ON c.id = e.college_id AND e.status = 'active'
      LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
      LEFT JOIN attendance a ON e.id = a.event_id
      LEFT JOIN feedback f ON e.id = f.event_id
      GROUP BY c.id
      ORDER BY total_attendance DESC, overall_attendance_percentage DESC
    `;
    
    const colleges = await allQuery(sql);
    
    res.json({
      success: true,
      data: colleges,
      count: colleges.length,
      report_type: 'College Performance Report'
    });
  } catch (error) {
    console.error('Error generating college performance report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate college performance report',
      message: error.message
    });
  }
});

// Monthly Event Trends Report
router.get('/monthly-trends', async (req, res) => {
  try {
    const { college_id, year } = req.query;
    const currentYear = year || new Date().getFullYear();
    
    let sql = `
      SELECT 
        strftime('%m', e.start_date) as month,
        strftime('%Y', e.start_date) as year,
        COUNT(DISTINCT e.id) as events_count,
        COUNT(DISTINCT r.id) as registrations_count,
        COUNT(DISTINCT a.id) as attendance_count,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_rating
      FROM events e
      LEFT JOIN colleges c ON e.college_id = c.id
      LEFT JOIN registrations r ON e.id = r.event_id AND r.status = 'registered'
      LEFT JOIN attendance a ON e.id = a.event_id
      LEFT JOIN feedback f ON e.id = f.event_id
      WHERE strftime('%Y', e.start_date) = ? AND e.status = 'active'
    `;
    
    const params = [currentYear.toString()];
    
    if (college_id) {
      sql += ' AND e.college_id = ?';
      params.push(college_id);
    }
    
    sql += `
      GROUP BY strftime('%m', e.start_date), strftime('%Y', e.start_date)
      ORDER BY month
    `;
    
    const trends = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: trends,
      count: trends.length,
      report_type: 'Monthly Event Trends Report',
      year: currentYear
    });
  } catch (error) {
    console.error('Error generating monthly trends report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate monthly trends report',
      message: error.message
    });
  }
});

// Department-wise Participation Report
router.get('/department-participation', async (req, res) => {
  try {
    const { college_id } = req.query;
    
    let sql = `
      SELECT 
        s.department,
        c.name as college_name,
        COUNT(DISTINCT s.id) as total_students,
        COUNT(DISTINCT r.id) as total_registrations,
        COUNT(DISTINCT a.id) as total_attendance,
        ROUND(
          (COUNT(DISTINCT a.id) * 100.0 / NULLIF(COUNT(DISTINCT r.id), 0)), 2
        ) as attendance_percentage,
        ROUND(AVG(f.rating), 2) as average_rating,
        COUNT(DISTINCT f.id) as total_feedback
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      LEFT JOIN registrations r ON s.id = r.student_id AND r.status = 'registered'
      LEFT JOIN attendance a ON s.id = a.student_id
      LEFT JOIN feedback f ON s.id = f.student_id
      WHERE s.department IS NOT NULL
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND s.college_id = ?';
      params.push(college_id);
    }
    
    sql += `
      GROUP BY s.department, s.college_id
      ORDER BY total_attendance DESC, attendance_percentage DESC
    `;
    
    const departments = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: departments,
      count: departments.length,
      report_type: 'Department-wise Participation Report'
    });
  } catch (error) {
    console.error('Error generating department participation report:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate department participation report',
      message: error.message
    });
  }
});

// Get all available reports
router.get('/list', async (req, res) => {
  try {
    const reports = [
      {
        name: 'Event Popularity Report',
        endpoint: '/api/reports/event-popularity',
        description: 'Events sorted by number of registrations with attendance and feedback metrics',
        parameters: ['college_id', 'event_type', 'limit', 'offset']
      },
      {
        name: 'Student Participation Report',
        endpoint: '/api/reports/student-participation',
        description: 'Students ranked by event attendance and participation metrics',
        parameters: ['college_id', 'department', 'year_of_study', 'limit', 'offset']
      },
      {
        name: 'Top Active Students',
        endpoint: '/api/reports/top-active-students',
        description: 'Top 3 most active students based on attendance and feedback',
        parameters: ['college_id', 'limit']
      },
      {
        name: 'Event Type Analysis',
        endpoint: '/api/reports/event-type-analysis',
        description: 'Analysis of different event types with performance metrics',
        parameters: ['college_id']
      },
      {
        name: 'College Performance Report',
        endpoint: '/api/reports/college-performance',
        description: 'Performance comparison across all colleges',
        parameters: []
      },
      {
        name: 'Monthly Event Trends',
        endpoint: '/api/reports/monthly-trends',
        description: 'Monthly trends in event registrations and attendance',
        parameters: ['college_id', 'year']
      },
      {
        name: 'Department Participation Report',
        endpoint: '/api/reports/department-participation',
        description: 'Department-wise participation and performance metrics',
        parameters: ['college_id']
      }
    ];
    
    res.json({
      success: true,
      data: reports,
      count: reports.length
    });
  } catch (error) {
    console.error('Error fetching reports list:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch reports list',
      message: error.message
    });
  }
});

module.exports = router;
