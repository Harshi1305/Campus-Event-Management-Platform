const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all feedback (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { event_id, student_id, min_rating, max_rating, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT f.*, e.title as event_title, e.event_type, e.start_date,
             s.name as student_name, s.email as student_email,
             c.name as college_name
      FROM feedback f
      LEFT JOIN events e ON f.event_id = e.id
      LEFT JOIN students s ON f.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (event_id) {
      sql += ' AND f.event_id = ?';
      params.push(event_id);
    }
    
    if (student_id) {
      sql += ' AND f.student_id = ?';
      params.push(student_id);
    }
    
    if (min_rating) {
      sql += ' AND f.rating >= ?';
      params.push(min_rating);
    }
    
    if (max_rating) {
      sql += ' AND f.rating <= ?';
      params.push(max_rating);
    }
    
    sql += ' ORDER BY f.submitted_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const feedback = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: feedback,
      count: feedback.length
    });
  } catch (error) {
    console.error('Error fetching feedback:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch feedback',
      message: error.message
    });
  }
});

// Submit feedback
router.post('/', async (req, res) => {
  try {
    const { event_id, student_id, rating, comment } = req.body;
    
    // Validate required fields
    if (!event_id || !student_id || !rating) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['event_id', 'student_id', 'rating']
      });
    }
    
    // Validate rating range
    if (rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        error: 'Rating must be between 1 and 5'
      });
    }
    
    // Check if student attended the event
    const attendance = await getQuery(`
      SELECT * FROM attendance WHERE event_id = ? AND student_id = ?
    `, [event_id, student_id]);
    
    if (!attendance) {
      return res.status(400).json({
        success: false,
        error: 'Student must attend the event to provide feedback'
      });
    }
    
    // Check if feedback already exists
    const existingFeedback = await getQuery(`
      SELECT * FROM feedback WHERE event_id = ? AND student_id = ?
    `, [event_id, student_id]);
    
    if (existingFeedback) {
      return res.status(400).json({
        success: false,
        error: 'Feedback already submitted for this event'
      });
    }
    
    const result = await runQuery(`
      INSERT INTO feedback (event_id, student_id, rating, comment) VALUES (?, ?, ?, ?)
    `, [event_id, student_id, rating, comment]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'Feedback submitted successfully'
      }
    });
  } catch (error) {
    console.error('Error submitting feedback:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to submit feedback',
      message: error.message
    });
  }
});

// Update feedback
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, comment } = req.body;
    
    // Validate rating if provided
    if (rating !== undefined && (rating < 1 || rating > 5)) {
      return res.status(400).json({
        success: false,
        error: 'Rating must be between 1 and 5'
      });
    }
    
    // Build dynamic update query
    const fields = [];
    const values = [];
    
    if (rating !== undefined) {
      fields.push('rating = ?');
      values.push(rating);
    }
    
    if (comment !== undefined) {
      fields.push('comment = ?');
      values.push(comment);
    }
    
    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No fields to update'
      });
    }
    
    values.push(id);
    
    const result = await runQuery(`
      UPDATE feedback SET ${fields.join(', ')} WHERE id = ?
    `, values);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Feedback not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Feedback updated successfully',
        changes: result.changes
      }
    });
  } catch (error) {
    console.error('Error updating feedback:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update feedback',
      message: error.message
    });
  }
});

// Get feedback for a specific event
router.get('/event/:event_id', async (req, res) => {
  try {
    const { event_id } = req.params;
    const { min_rating, max_rating, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT f.*, s.name as student_name, s.email as student_email,
             s.year_of_study, s.department, c.name as college_name
      FROM feedback f
      LEFT JOIN students s ON f.student_id = s.id
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE f.event_id = ?
    `;
    
    const params = [event_id];
    
    if (min_rating) {
      sql += ' AND f.rating >= ?';
      params.push(min_rating);
    }
    
    if (max_rating) {
      sql += ' AND f.rating <= ?';
      params.push(max_rating);
    }
    
    sql += ' ORDER BY f.submitted_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const feedback = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: feedback,
      count: feedback.length
    });
  } catch (error) {
    console.error('Error fetching event feedback:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch event feedback',
      message: error.message
    });
  }
});

// Get feedback summary for an event
router.get('/event/:event_id/summary', async (req, res) => {
  try {
    const { event_id } = req.params;
    
    const summary = await getQuery(`
      SELECT 
        COUNT(*) as total_feedback,
        AVG(rating) as average_rating,
        MIN(rating) as min_rating,
        MAX(rating) as max_rating,
        COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star_count,
        COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star_count,
        COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star_count,
        COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star_count,
        COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star_count
      FROM feedback
      WHERE event_id = ?
    `, [event_id]);
    
    res.json({
      success: true,
      data: summary
    });
  } catch (error) {
    console.error('Error fetching feedback summary:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch feedback summary',
      message: error.message
    });
  }
});

module.exports = router;
