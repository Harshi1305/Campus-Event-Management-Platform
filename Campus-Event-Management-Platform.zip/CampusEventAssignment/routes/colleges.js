const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all colleges
router.get('/', async (req, res) => {
  try {
    const colleges = await allQuery(`
      SELECT c.*, 
             COUNT(DISTINCT s.id) as total_students,
             COUNT(DISTINCT e.id) as total_events
      FROM colleges c
      LEFT JOIN students s ON c.id = s.college_id
      LEFT JOIN events e ON c.id = e.college_id
      GROUP BY c.id
      ORDER BY c.name
    `);
    
    res.json({
      success: true,
      data: colleges,
      count: colleges.length
    });
  } catch (error) {
    console.error('Error fetching colleges:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch colleges',
      message: error.message
    });
  }
});

// Get college by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const college = await getQuery(`
      SELECT c.*, 
             COUNT(DISTINCT s.id) as total_students,
             COUNT(DISTINCT e.id) as total_events,
             COUNT(DISTINCT r.id) as total_registrations
      FROM colleges c
      LEFT JOIN students s ON c.id = s.college_id
      LEFT JOIN events e ON c.id = e.college_id
      LEFT JOIN registrations r ON e.id = r.event_id
      WHERE c.id = ?
      GROUP BY c.id
    `, [id]);
    
    if (!college) {
      return res.status(404).json({
        success: false,
        error: 'College not found'
      });
    }
    
    res.json({
      success: true,
      data: college
    });
  } catch (error) {
    console.error('Error fetching college:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch college',
      message: error.message
    });
  }
});

// Create new college
router.post('/', async (req, res) => {
  try {
    const { name, code, location } = req.body;
    
    // Validate required fields
    if (!name || !code) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['name', 'code']
      });
    }
    
    const result = await runQuery(`
      INSERT INTO colleges (name, code, location) VALUES (?, ?, ?)
    `, [name, code, location]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'College created successfully'
      }
    });
  } catch (error) {
    console.error('Error creating college:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create college',
      message: error.message
    });
  }
});

module.exports = router;
