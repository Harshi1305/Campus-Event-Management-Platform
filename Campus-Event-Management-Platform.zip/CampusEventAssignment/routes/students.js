const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all students (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { college_id, department, year_of_study, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT s.*, c.name as college_name, c.code as college_code,
             COUNT(DISTINCT r.id) as events_registered,
             COUNT(DISTINCT a.id) as events_attended
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      LEFT JOIN registrations r ON s.id = r.student_id
      LEFT JOIN attendance a ON s.id = a.student_id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND s.college_id = ?';
      params.push(college_id);
    }
    
    if (department) {
      sql += ' AND s.department = ?';
      params.push(department);
    }
    
    if (year_of_study) {
      sql += ' AND s.year_of_study = ?';
      params.push(year_of_study);
    }
    
    sql += ' GROUP BY s.id ORDER BY s.name LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const students = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: students,
      count: students.length
    });
  } catch (error) {
    console.error('Error fetching students:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch students',
      message: error.message
    });
  }
});

// Get student by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const student = await getQuery(`
      SELECT s.*, c.name as college_name, c.code as college_code
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE s.id = ?
    `, [id]);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        error: 'Student not found'
      });
    }
    
    // Get student's event participation
    const participation = await allQuery(`
      SELECT e.title, e.event_type, e.start_date,
             r.registration_date, a.check_in_time, f.rating, f.comment
      FROM registrations r
      LEFT JOIN events e ON r.event_id = e.id
      LEFT JOIN attendance a ON r.event_id = a.event_id AND r.student_id = a.student_id
      LEFT JOIN feedback f ON r.event_id = f.event_id AND r.student_id = f.student_id
      WHERE r.student_id = ?
      ORDER BY e.start_date DESC
    `, [id]);
    
    res.json({
      success: true,
      data: {
        ...student,
        participation
      }
    });
  } catch (error) {
    console.error('Error fetching student:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch student',
      message: error.message
    });
  }
});

// Create new student
router.post('/', async (req, res) => {
  try {
    const {
      college_id,
      student_id,
      name,
      email,
      phone,
      year_of_study,
      department
    } = req.body;
    
    // Validate required fields
    if (!college_id || !student_id || !name || !email) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['college_id', 'student_id', 'name', 'email']
      });
    }
    
    const result = await runQuery(`
      INSERT INTO students (
        college_id, student_id, name, email, phone, year_of_study, department
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [college_id, student_id, name, email, phone, year_of_study, department]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'Student created successfully'
      }
    });
  } catch (error) {
    console.error('Error creating student:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create student',
      message: error.message
    });
  }
});

// Update student
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    // Build dynamic update query
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No fields to update'
      });
    }
    
    values.push(id);
    
    const result = await runQuery(`
      UPDATE students SET ${fields.join(', ')} WHERE id = ?
    `, values);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Student not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Student updated successfully',
        changes: result.changes
      }
    });
  } catch (error) {
    console.error('Error updating student:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update student',
      message: error.message
    });
  }
});

// Get student by college and student_id
router.get('/college/:college_id/student/:student_id', async (req, res) => {
  try {
    const { college_id, student_id } = req.params;
    
    const student = await getQuery(`
      SELECT s.*, c.name as college_name, c.code as college_code
      FROM students s
      LEFT JOIN colleges c ON s.college_id = c.id
      WHERE s.college_id = ? AND s.student_id = ?
    `, [college_id, student_id]);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        error: 'Student not found'
      });
    }
    
    res.json({
      success: true,
      data: student
    });
  } catch (error) {
    console.error('Error fetching student:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch student',
      message: error.message
    });
  }
});

module.exports = router;
