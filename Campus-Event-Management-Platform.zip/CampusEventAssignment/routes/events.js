const express = require('express');
const router = express.Router();
const { runQuery, getQuery, allQuery } = require('../database/db');

// Get all events (with optional filtering)
router.get('/', async (req, res) => {
  try {
    const { college_id, event_type, status, limit = 50, offset = 0 } = req.query;
    
    let sql = `
      SELECT e.*, c.name as college_name, c.code as college_code,
             COUNT(r.id) as registration_count,
             COUNT(a.id) as attendance_count
      FROM events e
      LEFT JOIN colleges c ON e.college_id = c.id
      LEFT JOIN registrations r ON e.id = r.event_id
      LEFT JOIN attendance a ON e.id = a.event_id
      WHERE 1=1
    `;
    
    const params = [];
    
    if (college_id) {
      sql += ' AND e.college_id = ?';
      params.push(college_id);
    }
    
    if (event_type) {
      sql += ' AND e.event_type = ?';
      params.push(event_type);
    }
    
    if (status) {
      sql += ' AND e.status = ?';
      params.push(status);
    }
    
    sql += ' GROUP BY e.id ORDER BY e.start_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    
    const events = await allQuery(sql, params);
    
    res.json({
      success: true,
      data: events,
      count: events.length
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch events',
      message: error.message
    });
  }
});

// Get event by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const event = await getQuery(`
      SELECT e.*, c.name as college_name, c.code as college_code,
             COUNT(DISTINCT r.id) as registration_count,
             COUNT(DISTINCT a.id) as attendance_count,
             AVG(f.rating) as avg_rating
      FROM events e
      LEFT JOIN colleges c ON e.college_id = c.id
      LEFT JOIN registrations r ON e.id = r.event_id
      LEFT JOIN attendance a ON e.id = a.event_id
      LEFT JOIN feedback f ON e.id = f.event_id
      WHERE e.id = ?
      GROUP BY e.id
    `, [id]);
    
    if (!event) {
      return res.status(404).json({
        success: false,
        error: 'Event not found'
      });
    }
    
    res.json({
      success: true,
      data: event
    });
  } catch (error) {
    console.error('Error fetching event:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch event',
      message: error.message
    });
  }
});

// Create new event
router.post('/', async (req, res) => {
  try {
    const {
      college_id,
      title,
      description,
      event_type,
      start_date,
      end_date,
      location,
      max_capacity,
      registration_deadline,
      created_by
    } = req.body;
    
    // Validate required fields
    if (!college_id || !title || !event_type || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields',
        required: ['college_id', 'title', 'event_type', 'start_date', 'end_date']
      });
    }
    
    const result = await runQuery(`
      INSERT INTO events (
        college_id, title, description, event_type, start_date, end_date,
        location, max_capacity, registration_deadline, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      college_id, title, description, event_type, start_date, end_date,
      location, max_capacity, registration_deadline, created_by
    ]);
    
    res.status(201).json({
      success: true,
      data: {
        id: result.id,
        message: 'Event created successfully'
      }
    });
  } catch (error) {
    console.error('Error creating event:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create event',
      message: error.message
    });
  }
});

// Update event
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    
    // Build dynamic update query
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No fields to update'
      });
    }
    
    values.push(id);
    
    const result = await runQuery(`
      UPDATE events SET ${fields.join(', ')} WHERE id = ?
    `, values);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Event not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Event updated successfully',
        changes: result.changes
      }
    });
  } catch (error) {
    console.error('Error updating event:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update event',
      message: error.message
    });
  }
});

// Delete event
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await runQuery('DELETE FROM events WHERE id = ?', [id]);
    
    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: 'Event not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        message: 'Event deleted successfully'
      }
    });
  } catch (error) {
    console.error('Error deleting event:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete event',
      message: error.message
    });
  }
});

// Get event types
router.get('/types/list', async (req, res) => {
  try {
    const types = await allQuery(`
      SELECT DISTINCT event_type, COUNT(*) as count
      FROM events
      GROUP BY event_type
      ORDER BY count DESC
    `);
    
    res.json({
      success: true,
      data: types
    });
  } catch (error) {
    console.error('Error fetching event types:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch event types',
      message: error.message
    });
  }
});

module.exports = router;
