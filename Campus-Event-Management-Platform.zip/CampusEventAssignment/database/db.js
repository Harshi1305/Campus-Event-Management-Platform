const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Database file path
const DB_PATH = path.join(__dirname, 'campus_events.db');

// Create database connection
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Error opening database:', err.message);
  } else {
    console.log('✅ Connected to SQLite database');
  }
});

// Enable foreign keys
db.run('PRAGMA foreign_keys = ON');

// Database initialization function
const initDatabase = () => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Colleges table
      db.run(`
        CREATE TABLE IF NOT EXISTS colleges (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          code TEXT NOT NULL UNIQUE,
          location TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Students table
      db.run(`
        CREATE TABLE IF NOT EXISTS students (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          college_id INTEGER NOT NULL,
          student_id TEXT NOT NULL,
          name TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT,
          year_of_study INTEGER,
          department TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (college_id) REFERENCES colleges (id),
          UNIQUE(college_id, student_id)
        )
      `);

      // Events table
      db.run(`
        CREATE TABLE IF NOT EXISTS events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          college_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          description TEXT,
          event_type TEXT NOT NULL,
          start_date DATETIME NOT NULL,
          end_date DATETIME NOT NULL,
          location TEXT,
          max_capacity INTEGER,
          registration_deadline DATETIME,
          status TEXT DEFAULT 'active',
          created_by TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (college_id) REFERENCES colleges (id)
        )
      `);

      // Registrations table
      db.run(`
        CREATE TABLE IF NOT EXISTS registrations (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          event_id INTEGER NOT NULL,
          student_id INTEGER NOT NULL,
          registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
          status TEXT DEFAULT 'registered',
          FOREIGN KEY (event_id) REFERENCES events (id),
          FOREIGN KEY (student_id) REFERENCES students (id),
          UNIQUE(event_id, student_id)
        )
      `);

      // Attendance table
      db.run(`
        CREATE TABLE IF NOT EXISTS attendance (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          event_id INTEGER NOT NULL,
          student_id INTEGER NOT NULL,
          check_in_time DATETIME DEFAULT CURRENT_TIMESTAMP,
          check_out_time DATETIME,
          status TEXT DEFAULT 'present',
          FOREIGN KEY (event_id) REFERENCES events (id),
          FOREIGN KEY (student_id) REFERENCES students (id),
          UNIQUE(event_id, student_id)
        )
      `);

      // Feedback table
      db.run(`
        CREATE TABLE IF NOT EXISTS feedback (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          event_id INTEGER NOT NULL,
          student_id INTEGER NOT NULL,
          rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
          comment TEXT,
          submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (event_id) REFERENCES events (id),
          FOREIGN KEY (student_id) REFERENCES students (id),
          UNIQUE(event_id, student_id)
        )
      `);

      // Create indexes for better performance
      db.run('CREATE INDEX IF NOT EXISTS idx_events_college ON events(college_id)');
      db.run('CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type)');
      db.run('CREATE INDEX IF NOT EXISTS idx_events_date ON events(start_date)');
      db.run('CREATE INDEX IF NOT EXISTS idx_registrations_event ON registrations(event_id)');
      db.run('CREATE INDEX IF NOT EXISTS idx_registrations_student ON registrations(student_id)');
      db.run('CREATE INDEX IF NOT EXISTS idx_attendance_event ON attendance(event_id)');
      db.run('CREATE INDEX IF NOT EXISTS idx_feedback_event ON feedback(event_id)');
      db.run('CREATE INDEX IF NOT EXISTS idx_students_college ON students(college_id)');

      console.log('✅ Database tables created successfully');
      resolve();
    });
  });
};

// Helper function to run queries with promises
const runQuery = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        reject(err);
      } else {
        resolve({ id: this.lastID, changes: this.changes });
      }
    });
  });
};

const getQuery = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row);
      }
    });
  });
};

const allQuery = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
};

module.exports = {
  db,
  initDatabase,
  runQuery,
  getQuery,
  allQuery
};
