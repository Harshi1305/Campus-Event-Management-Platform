# Campus Event Management Platform - Design Document

## Project Overview

This document outlines the design and implementation of a comprehensive Campus Event Management Platform with a focus on event reporting and analytics. The system is designed to handle event creation, student registration, attendance tracking, feedback collection, and comprehensive reporting across multiple colleges.

## System Architecture

### Technology Stack
- **Backend**: Node.js with Express.js
- **Database**: SQLite (for development/prototype)
- **API**: RESTful API design
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Deployment**: Local development environment

### Scale Assumptions
- **Colleges**: ~50 colleges
- **Students per college**: ~500 students
- **Events per semester**: ~20 events per college
- **Total scale**: 25,000 students, 1,000 events per semester

## Database Design

### Entity Relationship Diagram

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│    COLLEGES     │    │    STUDENTS     │    │     EVENTS      │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ id (PK)         │    │ id (PK)         │    │ id (PK)         │
│ name            │◄───┤ college_id (FK) │    │ college_id (FK) │
│ code            │    │ student_id      │    │ title           │
│ location        │    │ name            │    │ description     │
│ created_at      │    │ email           │    │ event_type      │
└─────────────────┘    │ phone           │    │ start_date      │
                       │ year_of_study   │    │ end_date        │
                       │ department      │    │ location        │
                       │ created_at      │    │ max_capacity    │
                       └─────────────────┘    │ registration_   │
                                              │   deadline      │
                                              │ status          │
                                              │ created_by      │
                                              │ created_at      │
                                              └─────────────────┘
                                                       │
                                                       │
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ REGISTRATIONS   │    │   ATTENDANCE    │    │    FEEDBACK     │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ id (PK)         │    │ id (PK)         │    │ id (PK)         │
│ event_id (FK)   │◄───┤ event_id (FK)   │    │ event_id (FK)   │
│ student_id (FK) │    │ student_id (FK) │    │ student_id (FK) │
│ registration_   │    │ check_in_time   │    │ rating (1-5)    │
│   date          │    │ check_out_time  │    │ comment         │
│ status          │    │ status          │    │ submitted_at    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Database Schema Details

#### 1. Colleges Table
- **Purpose**: Store college/university information
- **Key Fields**: 
  - `id`: Primary key
  - `name`: College name
  - `code`: Unique college code
  - `location`: College location

#### 2. Students Table
- **Purpose**: Store student information
- **Key Fields**:
  - `id`: Primary key
  - `college_id`: Foreign key to colleges
  - `student_id`: Unique student ID within college
  - `name`, `email`, `phone`: Contact information
  - `year_of_study`, `department`: Academic information

#### 3. Events Table
- **Purpose**: Store event information
- **Key Fields**:
  - `id`: Primary key
  - `college_id`: Foreign key to colleges
  - `title`, `description`: Event details
  - `event_type`: Type of event (Workshop, Fest, Seminar, Competition)
  - `start_date`, `end_date`: Event timing
  - `max_capacity`: Maximum attendees
  - `registration_deadline`: Registration cutoff

#### 4. Registrations Table
- **Purpose**: Track student event registrations
- **Key Fields**:
  - `event_id`, `student_id`: Composite foreign keys
  - `registration_date`: When student registered
  - `status`: Registration status (registered, cancelled)

#### 5. Attendance Table
- **Purpose**: Track actual event attendance
- **Key Fields**:
  - `event_id`, `student_id`: Composite foreign keys
  - `check_in_time`, `check_out_time`: Attendance timing
  - `status`: Attendance status (present, absent)

#### 6. Feedback Table
- **Purpose**: Store event feedback from students
- **Key Fields**:
  - `event_id`, `student_id`: Composite foreign keys
  - `rating`: 1-5 star rating
  - `comment`: Text feedback
  - `submitted_at`: Feedback submission time

## API Design

### Base URL
```
http://localhost:3000/api
```

### Core Endpoints

#### Events Management
- `GET /events` - List all events with filtering
- `GET /events/:id` - Get specific event details
- `POST /events` - Create new event
- `PUT /events/:id` - Update event
- `DELETE /events/:id` - Delete event

#### Student Management
- `GET /students` - List all students
- `GET /students/:id` - Get student details
- `POST /students` - Create new student
- `PUT /students/:id` - Update student

#### Registration Management
- `GET /registrations` - List all registrations
- `POST /registrations` - Register student for event
- `DELETE /registrations/:id` - Cancel registration

#### Attendance Management
- `GET /attendance` - List attendance records
- `POST /attendance/checkin` - Mark attendance
- `PUT /attendance/checkout/:id` - Mark checkout

#### Feedback Management
- `GET /feedback` - List all feedback
- `POST /feedback` - Submit feedback
- `PUT /feedback/:id` - Update feedback

### Reporting Endpoints

#### Core Reports (Required)
1. **Event Popularity Report**
   - `GET /reports/event-popularity`
   - Sorted by registration count
   - Includes attendance percentage and average rating

2. **Student Participation Report**
   - `GET /reports/student-participation`
   - Shows events attended per student
   - Includes attendance percentage

#### Bonus Reports
3. **Top Active Students**
   - `GET /reports/top-active-students`
   - Top 3 most active students
   - Based on attendance and feedback activity

4. **Event Type Analysis**
   - `GET /reports/event-type-analysis`
   - Performance by event type
   - Flexible filtering capabilities

5. **College Performance Report**
   - `GET /reports/college-performance`
   - Cross-college comparison
   - Overall metrics and rankings

6. **Monthly Trends Report**
   - `GET /reports/monthly-trends`
   - Time-based analysis
   - Seasonal patterns and trends

7. **Department Participation Report**
   - `GET /reports/department-participation`
   - Department-wise engagement
   - Academic performance insights

## Workflows

### 1. Event Registration Workflow
```
Student → Browse Events → Register → Receive Confirmation → Attend Event
```

### 2. Attendance Tracking Workflow
```
Event Day → Check-in → Participate → Check-out → Submit Feedback
```

### 3. Reporting Workflow
```
Data Collection → Analytics Processing → Report Generation → Insights
```

## Key Assumptions & Decisions

### Data Architecture Decisions
1. **Multi-tenant Design**: Each college has separate data but shared schema
2. **Event ID Uniqueness**: Event IDs are unique across all colleges
3. **Student ID Scope**: Student IDs are unique within each college
4. **Registration Validation**: Students can only register for active events
5. **Attendance Prerequisites**: Only registered students can mark attendance
6. **Feedback Requirements**: Only attending students can submit feedback

### Business Logic Assumptions
1. **Event Capacity**: Events have maximum capacity limits
2. **Registration Deadlines**: Events have registration cutoff dates
3. **Event Status**: Events can be active, cancelled, or completed
4. **Rating Scale**: Feedback uses 1-5 star rating system
5. **Attendance Tracking**: Both check-in and check-out times are recorded
6. **Duplicate Prevention**: Unique constraints prevent duplicate registrations

### Edge Cases Handled
1. **Duplicate Registrations**: Prevented by unique constraints
2. **Missing Feedback**: Optional feedback with default handling
3. **Cancelled Events**: Status tracking and impact on reports
4. **Capacity Overflow**: Registration validation against max capacity
5. **Deadline Violations**: Registration deadline enforcement
6. **Invalid Ratings**: Rating validation (1-5 range)
7. **Orphaned Records**: Foreign key constraints maintain data integrity

### Performance Considerations
1. **Database Indexing**: Strategic indexes on frequently queried fields
2. **Query Optimization**: Efficient joins and aggregations
3. **Pagination**: Limit and offset for large result sets
4. **Caching Strategy**: Consider Redis for production deployment
5. **Connection Pooling**: Database connection management

## Security Considerations

### Data Protection
1. **Input Validation**: All API inputs are validated
2. **SQL Injection Prevention**: Parameterized queries
3. **Data Sanitization**: Clean user inputs
4. **Access Control**: Role-based access (future enhancement)

### Privacy
1. **Student Data**: Minimal required information collection
2. **Feedback Anonymity**: Optional anonymous feedback
3. **Data Retention**: Configurable data retention policies

## Scalability Considerations

### Current Prototype Limitations
1. **Single Database**: SQLite for development
2. **No Caching**: Direct database queries
3. **Synchronous Processing**: No background jobs
4. **Single Instance**: No load balancing

### Production Recommendations
1. **Database**: PostgreSQL or MySQL for production
2. **Caching**: Redis for session and query caching
3. **Background Jobs**: Queue system for heavy operations
4. **Load Balancing**: Multiple API instances
5. **CDN**: Static asset delivery
6. **Monitoring**: Application performance monitoring

## Testing Strategy

### Unit Testing
- Individual function testing
- Database operation testing
- API endpoint testing

### Integration Testing
- End-to-end workflow testing
- Database integration testing
- API integration testing

### Performance Testing
- Load testing with sample data
- Query performance analysis
- Response time optimization

## Deployment Architecture

### Development Environment
- Local Node.js server
- SQLite database
- File-based logging

### Production Environment (Recommended)
- Docker containerization
- PostgreSQL database
- Redis caching
- Nginx reverse proxy
- PM2 process management
- Log aggregation (ELK stack)

## Future Enhancements

### Phase 2 Features
1. **Authentication System**: JWT-based authentication
2. **Role-based Access**: Admin, Student, Faculty roles
3. **Real-time Notifications**: WebSocket integration
4. **Mobile App**: React Native or Flutter app
5. **Advanced Analytics**: Machine learning insights
6. **Integration APIs**: Third-party service integration

### Phase 3 Features
1. **Multi-language Support**: Internationalization
2. **Advanced Reporting**: Custom report builder
3. **Event Recommendations**: AI-powered suggestions
4. **Social Features**: Student networking
5. **Payment Integration**: Event fees and payments

## Conclusion

This design document provides a comprehensive overview of the Campus Event Management Platform. The system is designed to be scalable, maintainable, and extensible while meeting the current requirements for event management and reporting. The modular architecture allows for future enhancements and integrations as the platform grows.

The prototype implementation demonstrates all core functionality with a focus on the reporting system that provides valuable insights into event popularity, student participation, and overall platform performance.
