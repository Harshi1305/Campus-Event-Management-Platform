# 🎓 Campus Event Management Platform - User Guide

## 🚀 **System is Live and Ready!**

**Access the platform at: http://localhost:3000**

---

## 👥 **User Types & Login**

### **Student Login**
- **Select College**: Choose from IIT Delhi, IIT Bombay, IIT Madras, DTU, NSUT
- **Enter Student ID**: Use sample IDs like:
  - `IITD2021001` (Arjun Sharma - IIT Delhi)
  - `IITB2021001` (Ananya Reddy - IIT Bombay)
  - `DTU2021001` (Amit Verma - DTU)

### **Staff Login**
- **Select College**: Choose your college
- **Enter Name**: Any name for demo purposes

---

## 🎯 **Student Features**

### **Dashboard**
- **My Statistics**: View events registered, attended, and attendance rate
- **Quick Actions**: Browse events, view registrations, check-in

### **Browse Events**
- View all available events in your college
- See event details: type, date, location, capacity
- **Register** for events with one click

### **My Registrations**
- Track all your event registrations
- See attendance status (Registered/Attended)
- **Cancel** registrations if needed

### **Check-in System**
- **On Event Day**: Use the check-in feature
- Select the event you're attending
- **Mark attendance** with one click

---

## 👨‍💼 **Staff Features**

### **Dashboard**
- **College Statistics**: Total events, students, registrations
- **Quick Actions**: Create events, manage events, view reports

### **Create Events**
- **Event Details**: Title, description, type, location
- **Scheduling**: Start/end dates, registration deadline
- **Capacity**: Set maximum attendees
- **Event Types**: Workshop, Fest, Seminar, Competition

### **Manage Events**
- View all college events
- See registration counts and attendance
- **Delete** events if needed

### **Reports & Analytics**
- **Event Popularity**: Events ranked by registrations
- **Student Participation**: Student engagement metrics
- **Top Active Students**: Most engaged students
- **Event Type Analysis**: Performance by event type
- **College Performance**: Cross-college comparison
- **Monthly Trends**: Time-based analysis
- **Department Participation**: Department-wise metrics

---

## 📊 **Sample Data Available**

### **Colleges (5)**
- IIT Delhi
- IIT Bombay  
- IIT Madras
- DTU (Delhi Technological University)
- NSUT (Netaji Subhas University of Technology)

### **Students (15)**
Ready-to-use student accounts:
- **IIT Delhi**: IITD2021001, IITD2021002, IITD2021003, IITD2021004, IITD2021005
- **IIT Bombay**: IITB2021001, IITB2021002, IITB2021003, IITB2021004, IITB2021005
- **DTU**: DTU2021001, DTU2021002, DTU2021003, DTU2021004, DTU2021005

### **Events (10)**
- **TechFest 2024** (IIT Delhi) - Fest
- **Machine Learning Workshop** (IIT Delhi) - Workshop
- **Startup Pitch Competition** (IIT Delhi) - Competition
- **AI in Healthcare Seminar** (IIT Delhi) - Seminar
- **Mood Indigo 2024** (IIT Bombay) - Fest
- **Blockchain Development Workshop** (IIT Bombay) - Workshop
- **Robotics Competition** (IIT Bombay) - Competition
- **Engifest 2024** (DTU) - Fest
- **Data Science Bootcamp** (DTU) - Workshop
- **Cybersecurity Awareness Talk** (DTU) - Seminar

---

## 🎮 **Demo Scenarios**

### **Scenario 1: Student Experience**
1. **Login** as student (IITD2021001)
2. **Browse Events** - see available events
3. **Register** for "TechFest 2024"
4. **Check-in** on event day
5. **View** your participation statistics

### **Scenario 2: Staff Experience**
1. **Login** as staff (IIT Delhi)
2. **Create** a new "Python Workshop"
3. **View** all college events
4. **Generate** event popularity report
5. **Monitor** student registrations

### **Scenario 3: Cross-College Analysis**
1. **Login** as staff from different colleges
2. **Create** events in each college
3. **Generate** college performance report
4. **Compare** metrics across institutions

---

## 🔧 **Technical Features**

### **Real-time Updates**
- Live data refresh
- Instant registration confirmations
- Real-time attendance tracking

### **Data Validation**
- Registration deadline enforcement
- Capacity limit checking
- Duplicate registration prevention
- Attendance prerequisite validation

### **Responsive Design**
- Works on desktop, tablet, and mobile
- Modern, professional interface
- Intuitive navigation

### **Error Handling**
- User-friendly error messages
- Validation feedback
- Graceful failure handling

---

## 📈 **Reporting System**

### **Available Reports**
1. **Event Popularity Report**
   - Events sorted by registration count
   - Attendance percentages
   - Average ratings

2. **Student Participation Report**
   - Student engagement metrics
   - Events attended per student
   - Attendance rates

3. **Top Active Students**
   - Most engaged students
   - Activity scores
   - Participation rankings

4. **Event Type Analysis**
   - Performance by event type
   - Registration patterns
   - Duration analysis

5. **College Performance Report**
   - Cross-college comparison
   - Overall metrics
   - Rankings

6. **Monthly Trends Report**
   - Time-based analysis
   - Seasonal patterns
   - Growth trends

7. **Department Participation Report**
   - Department-wise engagement
   - Academic performance insights

---

## 🎯 **Assignment Compliance**

### ✅ **All Requirements Met**
- **Admin Portal**: Staff can create and manage events
- **Student App**: Students can browse, register, and check-in
- **Event Reporting**: Comprehensive analytics system
- **Database Design**: Complete with ER diagram
- **API Design**: Full RESTful API
- **Prototype**: Working system with all features
- **Sample Data**: Comprehensive test data
- **Documentation**: Complete setup and usage guides

### ✅ **Bonus Features**
- **Top 3 Most Active Students**
- **Flexible Reports** with filtering
- **Modern Web Interface**
- **Additional Report Types**
- **Cross-College Analytics**

---

## 🚀 **Getting Started**

1. **Access**: Go to http://localhost:3000
2. **Choose Role**: Student or Staff login
3. **Select College**: Pick from available options
4. **Enter Credentials**: Use sample data provided
5. **Explore**: Try all the features!

---

## 🎉 **System Status**

- ✅ **Server**: Running on port 3000
- ✅ **Database**: SQLite with sample data
- ✅ **API**: All endpoints functional
- ✅ **Web Interface**: Fully responsive
- ✅ **Authentication**: Role-based access
- ✅ **Reports**: All 7 report types working
- ✅ **Event Management**: Full CRUD operations
- ✅ **Registration System**: Complete workflow
- ✅ **Attendance Tracking**: Check-in/check-out
- ✅ **Feedback System**: Rating and comments

**The Campus Event Management Platform is complete and ready for demonstration!**

---

## 📞 **Support**

- **Web Interface**: http://localhost:3000
- **API Base**: http://localhost:3000/api
- **Health Check**: http://localhost:3000/api/health
- **Documentation**: See README.md and DESIGN_DOCUMENT.md

**Enjoy exploring the complete campus event management system!** 🎓✨
